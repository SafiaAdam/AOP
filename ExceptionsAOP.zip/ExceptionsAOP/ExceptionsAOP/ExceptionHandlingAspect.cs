﻿using PostSharp.Aspects;
using PostSharp.Serialization;

[PSerializable]
public class ExceptionHandlingAspect : OnExceptionAspect
{
    public override void OnException(MethodExecutionArgs args)
    {
        // You can add custom exception handling logic here, like logging or notifying admins
        LogException(args.Exception);

        //Set method return value
        args.ReturnValue = false;

        ////Continue flow of program
        args.FlowBehavior = FlowBehavior.Continue;
    }

    private void LogException(Exception exception)
    {
        // Your custom logging logic goes here.
        Console.WriteLine($"Logging exception: {exception.Message}");
    }
}
