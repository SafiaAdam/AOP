﻿using PostSharp.Aspects;
using PostSharp.Serialization;


[PSerializable]
public class FileHandlingAspect : OnExceptionAspect
{
    public override void OnException(MethodExecutionArgs args)
    {
        // You can add custom exception handling logic here, like logging or notifying admins
        if(args.Exception is FileNotFoundException)
        {
            Console.WriteLine("File Not Found Exception");

            //Terminate program
            System.Environment.Exit(1);
        }
        else if(args.Exception is IOException)
        {
            Console.WriteLine("IO Exception");
        }
        else
        {
            Console.WriteLine("Unknown exception has occured");
        }

        //Continue flow of program
        args.FlowBehavior = FlowBehavior.Continue;
    }

}
