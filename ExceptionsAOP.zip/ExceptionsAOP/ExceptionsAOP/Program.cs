﻿using System;

namespace ExceptionsAOP
{
    class Program
    {
        public static void Main()
        {
            LoginService loginService = new();
            loginService.Login("username", "password");



         /*   try
             {
                loginService.Login("username", "pswd");
             }
             catch (Exception InvalidCredentials)
             {
               Console.WriteLine("exception occurred: " + ex.Message);
             }
         */
            Console.WriteLine("Test");

            }
        }
}
