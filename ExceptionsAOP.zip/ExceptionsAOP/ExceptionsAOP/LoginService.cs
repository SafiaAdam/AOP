﻿public class LoginService
{
    private string username = "username";
    private string password = "password";

   [ExceptionHandlingAspect] // Applying the aspect to handle exceptions
    public bool Login(string username, string password)
    {
        if (username == this.username && password == this.password)
        {
            Console.WriteLine("Login successful!");
            openFile();

            return true;
        }
        else
        {
            //Exception for incorrect login
            throw new Exception("Invalid credentials");
        }
    }

    [FileHandlingAspect]
    private void openFile()
    {
        try
        {
            using (FileStream fileStream = File.OpenRead("Test.txt"));
            Console.WriteLine("File Opened Succesfully");
        }
        catch
        {
            throw;
        }
    }
}